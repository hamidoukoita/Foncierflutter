import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_mobile_prospect_agent/core/theme/app_colors.dart';
import 'package:flutter_mobile_prospect_agent/features/prospect/catalogue/presentation/controllers/catalogue_provider.dart';
import 'package:flutter_mobile_prospect_agent/features/prospect/catalogue/presentation/widgets/lot_card.dart';

class ProgrammeDetailScreen extends ConsumerWidget {
  final int programmeId;

  const ProgrammeDetailScreen({super.key, required this.programmeId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final progAsync = ref.watch(programmeDetailProvider(programmeId));
    final lotsAsync = ref.watch(lotsByProgrammeProvider(programmeId));

    return Scaffold(
      backgroundColor: AppColors.backgroundOffWhite,
      appBar: AppBar(
        title: progAsync.when(
          data: (p) => Text(p.nom),
          loading: () => const Text('Programme'),
          error: (_, __) => const Text('Programme'),
        ),
      ),
      body: progAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
        data: (programme) {
          return RefreshIndicator(
            onRefresh: () async {
              ref.invalidate(programmeDetailProvider(programmeId));
              ref.invalidate(lotsByProgrammeProvider(programmeId));
            },
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _InfoCard(programme: programme),
                const SizedBox(height: 20),
                const Text(
                  'Lots disponibles',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                    color: AppColors.primaryBlueAnthracite,
                  ),
                ),
                const SizedBox(height: 12),
                lotsAsync.when(
                  loading: () => const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                  error: (e, _) => Text('Erreur lots : $e'),
                  data: (lots) {
                    if (lots.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Aucun lot pour ce programme.',
                          style: TextStyle(color: AppColors.grey500),
                        ),
                      );
                    }
                    return Column(
                      children: lots
                          .map(
                            (lot) => LotCard(
                              lot: lot,
                              onTap: () => context.push('/prospect/lots/${lot.id}'),
                            ),
                          )
                          .toList(),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final dynamic programme;
  const _InfoCard({required this.programme});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (programme.description != null &&
              (programme.description as String).isNotEmpty) ...[
            Text(programme.description as String,
                style: const TextStyle(fontSize: 13, height: 1.4)),
            const SizedBox(height: 12),
          ],
          _row(Icons.place_outlined, programme.lieu ?? '—'),
          if (programme.societeNom != null)
            _row(Icons.business_outlined, programme.societeNom as String),
          if (programme.superficieTotale != null)
            _row(Icons.square_foot, '${programme.superficieTotale} m²'),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              if (programme.eauSomapep == true) _badge('Eau'),
              if (programme.electriciteEdm == true) _badge('Électricité'),
              if (programme.voirieBitumee == true) _badge('Voirie'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _row(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Icon(icon, size: 18, color: AppColors.primaryOcre),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 13))),
        ],
      ),
    );
  }

  Widget _badge(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.primaryOcre.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: const TextStyle(
              fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.primaryOcre)),
    );
  }
}
