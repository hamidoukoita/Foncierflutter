import 'package:flutter/material.dart';
import 'package:flutter_mobile_prospect_agent/core/theme/app_colors.dart';
import 'package:flutter_mobile_prospect_agent/core/theme/app_radius.dart';
import 'package:flutter_mobile_prospect_agent/core/theme/app_spacing.dart';
import 'package:flutter_mobile_prospect_agent/core/theme/app_text_styles.dart';
import 'package:flutter_mobile_prospect_agent/features/prospect/catalogue/domain/programme_foncier.dart';

class ProgrammeCard extends StatelessWidget {
  final ProgrammeFoncier programme;
  final VoidCallback? onTap;

  const ProgrammeCard({super.key, required this.programme, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm + 4),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: AppRadius.card,
        side: const BorderSide(color: AppColors.borderLight),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: AppRadius.card,
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: AppColors.primaryOcre.withOpacity(0.12),
                  borderRadius: AppRadius.radiusLg,
                ),
                child: const Icon(Icons.location_city, color: AppColors.primaryOcre),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      programme.nom,
                      style: AppTextStyles.h4,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      programme.lieu?.isNotEmpty == true
                          ? programme.lieu!
                          : 'Localisation non renseignée',
                      style: AppTextStyles.bodySmall,
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      children: [
                        if (programme.totalLots != null)
                          _chip('${programme.totalLots} lots'),
                        if (programme.superficieTotale != null)
                          _chip('${programme.superficieTotale!.toStringAsFixed(0)} m²'),
                        if (programme.statut != null) _chip(programme.statut!),
                      ],
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: AppColors.grey500),
            ],
          ),
        ),
      ),
    );
  }

  Widget _chip(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.backgroundOffWhite,
        borderRadius: AppRadius.radiusSm,
      ),
      child: Text(text, style: AppTextStyles.bodySmall.copyWith(fontSize: 10, fontWeight: FontWeight.w600)),
    );
  }
}
