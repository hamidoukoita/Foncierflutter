class CurrencyFormatter {}
